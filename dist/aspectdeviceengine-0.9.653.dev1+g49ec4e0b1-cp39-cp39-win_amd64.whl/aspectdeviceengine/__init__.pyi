from __future__ import annotations
from . import enginecore
__all__: list = ['__doc__', '__version__', 'IdSmuService']
__version__: str = '0.9.653.dev1+g49ec4e0b1'
